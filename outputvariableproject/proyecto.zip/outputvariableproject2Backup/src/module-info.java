/**
 * 
 */
/**
 * 
 */
module outputvariableproject {
}